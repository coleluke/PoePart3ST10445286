﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CybersecurityChatbotWPF
{
    public partial class MainWindow : Window
    {
        private static readonly Random rand = new Random();

        // Tips data
        static readonly List<string> phishingTips = new List<string>
        {
            "Be cautious of emails asking for personal information.",
            "Never click on links in suspicious emails.",
            "Scammers often disguise themselves as trusted organisations.",
            "Look for spelling errors in suspicious emails — it's a giveaway!"
        };

        static readonly List<string> passwordTips = new List<string>
        {
            "Use a different password for each account.",
            "Your password should include numbers, symbols, and upper/lowercase letters.",
            "Avoid using names, birthdates, or common words in passwords.",
            "Consider using a password manager to store your credentials securely."
        };

        private string userName = "";
        private string userInterest = "";

        // Task assistant
        private ObservableCollection<CyberTask> tasks = new ObservableCollection<CyberTask>();

        // Quiz variables
        private List<QuizQuestion> quizQuestions = new List<QuizQuestion>();
        private int currentQuestionIndex = -1;
        private int score = 0;

        public MainWindow()
        {
            InitializeComponent();

            // Initialize task list binding
            lvTasks.ItemsSource = tasks;

            // Greet user
            AppendChatMessage("Bot: Welcome to the Cybersecurity Awareness Bot!");
            AppendChatMessage("Bot: What's your name?");

            InitializeQuizQuestions();
        }

        // Chatbox methods
        private void AppendChatMessage(string message)
        {
            txtChatHistory.AppendText(message + Environment.NewLine);
            txtChatHistory.ScrollToEnd();
        }

        private void PlayVoiceGreeting(string audioFilePath)
        {
            if (File.Exists(audioFilePath))
            {
                try
                {
                    using (SoundPlayer player = new SoundPlayer(audioFilePath))
                    {
                        player.PlaySync();
                    }
                }
                catch (Exception ex)
                {
                    AppendChatMessage($"Bot: [Error playing audio: {ex.Message}]");
                }
            }
            else
            {
                AppendChatMessage($"Bot: [Audio file {audioFilePath} is missing.]");
            }
        }

        private void PlayResponseSound()
        {
            System.Console.Beep(1000, 200);
        }

        private void ProcessUserInput(string userInput)
        {
            if (string.IsNullOrWhiteSpace(userInput))
            {
                AppendChatMessage("Bot: Please enter a message.");
                return;
            }

            AppendChatMessage($"You: {userInput}");

            if (string.IsNullOrEmpty(userName))
            {
                userName = userInput.Trim();
                AppendChatMessage($"Bot: Hello, {userName}! I'm here to help you stay safe online.");
                AppendChatMessage("Bot: You can ask me about password safety, phishing, malware, and more.");
                return;
            }

            HandleUserQuery(userInput);
        }

        private void HandleUserQuery(string userInput)
        {
            string input = userInput.ToLower();

            if (input.Contains("worried") || input.Contains("scared"))
            {
                PlayResponseSound();
                AppendChatMessage("Bot: It's okay to feel worried. You're taking the right step by learning how to stay safe.");
            }
            else if (input.Contains("curious"))
            {
                PlayResponseSound();
                AppendChatMessage("Bot: Curiosity is great! I'm ready to answer your questions.");
            }
            else if (input.Contains("frustrated") || input.Contains("confused"))
            {
                PlayResponseSound();
                AppendChatMessage("Bot: I get it — cybersecurity can be complex. Let's break it down together.");
            }
            else if (input.Contains("how are you") || input == "1")
            {
                PlayResponseSound();
                AppendChatMessage("Bot: I'm great, thank you! How can I assist you today?");
            }
            else if (input.Contains("what's your purpose") || input == "2")
            {
                PlayResponseSound();
                AppendChatMessage("Bot: I help you stay safe online by providing cybersecurity tips!");
            }
            else if (input.Contains("password") || input == "3")
            {
                PlayResponseSound();
                AppendChatMessage("Bot: " + passwordTips[rand.Next(passwordTips.Count)]);
            }
            else if (input.Contains("phishing") || input == "4")
            {
                PlayResponseSound();
                AppendChatMessage("Bot: " + phishingTips[rand.Next(phishingTips.Count)]);
            }
            else if (input.Contains("malware") || input == "5")
            {
                PlayResponseSound();
                AppendChatMessage("Bot: Keep your software updated and avoid suspicious downloads to prevent malware infections.");
            }
            else if (input.Contains("safe browsing") || input == "6")
            {
                PlayResponseSound();
                AppendChatMessage("Bot: Only visit trusted websites, look for HTTPS, and avoid clicking unknown links.");
            }
            else if (input.Contains("online privacy") || input == "7")
            {
                PlayResponseSound();
                AppendChatMessage("Bot: Use 2FA, manage your privacy settings, and avoid oversharing on public platforms.");
            }
            else if (input.Contains("social media security") || input == "8")
            {
                PlayResponseSound();
                AppendChatMessage("Bot: Use strong passwords, limit access to your posts, and don’t share personal info.");
            }
            else if (input.Contains("interested in"))
            {
                int index = input.IndexOf("interested in") + "interested in".Length;
                userInterest = input.Substring(index).Trim();
                PlayResponseSound();
                AppendChatMessage($"Bot: Great! I'll remember that you're interested in {userInterest}.");
            }
            else if (input.Contains("remind me"))
            {
                if (!string.IsNullOrEmpty(userInterest))
                {
                    PlayResponseSound();
                    AppendChatMessage($"Bot: As someone interested in {userInterest}, remember to review your security settings regularly.");
                }
                else
                {
                    AppendChatMessage("Bot: Sure! Please let me know what topic you're interested in first.");
                }
            }
            else if (input.Contains("exit") || input == "9")
            {
                PlayVoiceGreeting("goodbye.wav");
                AppendChatMessage("Bot: Goodbye! Stay safe online.");
                Application.Current.Shutdown();
            }
            else
            {
                System.Console.Beep(300, 500);
                AppendChatMessage("Bot: I didn't quite understand that. Could you rephrase?");
            }
        }

        // Button click handlers for chat input
        private void btnSend_Click(object sender, RoutedEventArgs e)
        {
            ProcessUserInput(txtUserInput.Text);
            txtUserInput.Clear();
            txtUserInput.Focus();
        }

        private void txtUserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                btnSend_Click(sender, e);
                e.Handled = true;
            }
        }

        // Task assistant button handlers
        private void btnAddTask_Click(object sender, RoutedEventArgs e)
        {
            string title = txtTaskTitle.Text.Trim();
            string description = txtTaskDescription.Text.Trim();
            DateTime? reminder = dpTaskReminder.SelectedDate;

            if (string.IsNullOrEmpty(title))
            {
                MessageBox.Show("Please enter a task title.");
                return;
            }

            CyberTask newTask = new CyberTask
            {
                Title = title,
                Description = description,
                ReminderDate = reminder,
                IsCompleted = false
            };

            tasks.Add(newTask);

            AppendChatMessage($"Bot: Task added: '{title}'." + (reminder.HasValue ? $" Reminder set for {reminder.Value:d}." : ""));

            // Clear inputs
            txtTaskTitle.Clear();
            txtTaskDescription.Clear();
            dpTaskReminder.SelectedDate = null;
        }

        private void btnDeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (lvTasks.SelectedItem is CyberTask selectedTask)
            {
                tasks.Remove(selectedTask);
                AppendChatMessage($"Bot: Task '{selectedTask.Title}' deleted.");
            }
            else
            {
                MessageBox.Show("Please select a task to delete.");
            }
        }

        private void btnMarkCompleted_Click(object sender, RoutedEventArgs e)
        {
            if (lvTasks.SelectedItem is CyberTask selectedTask)
            {
                selectedTask.IsCompleted = true;
                lvTasks.Items.Refresh();
                AppendChatMessage($"Bot: Task '{selectedTask.Title}' marked as completed.");
            }
            else
            {
                MessageBox.Show("Please select a task to mark as completed.");
            }
        }

        // Quiz methods
        private void InitializeQuizQuestions()
        {
            quizQuestions = new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "What should you do if you receive an email asking for your password?",
                    Options = new List<string> { "Reply with your password", "Delete the email", "Report the email as phishing", "Ignore it" },
                    CorrectOptionIndex = 2,
                    Explanation = "Correct! Reporting phishing emails helps prevent scams."
                },
                new QuizQuestion
                {
                    Question = "True or False: Using the same password for multiple accounts is safe.",
                    Options = new List<string> { "True", "False" },
                    CorrectOptionIndex = 1,
                    Explanation = "False. Using unique passwords for each account protects you if one password is compromised."
                },
                // Add more questions as needed...
            };
        }

        private void btnStartQuiz_Click(object sender, RoutedEventArgs e)
        {
            currentQuestionIndex = 0;
            score = 0;
            txtQuizFeedback.Text = "";
            ShowQuestion(currentQuestionIndex);
        }

        private void ShowQuestion(int index)
        {
            if (index < 0 || index >= quizQuestions.Count)
            {
                txtQuizQuestion.Text = "Quiz finished!";
                spAnswerOptions.Children.Clear();
                txtQuizFeedback.Text = $"Your final score is {score} out of {quizQuestions.Count}.";

                if (score == quizQuestions.Count)
                    AppendChatMessage("Bot: Great job! You’re a cybersecurity pro!");
                else
                    AppendChatMessage("Bot: Keep learning to stay safe online!");

                return;
            }

            var q = quizQuestions[index];
            txtQuizQuestion.Text = $"Q{index + 1}: {q.Question}";
            spAnswerOptions.Children.Clear();

            for (int i = 0; i < q.Options.Count; i++)
            {
                var rb = new RadioButton
                {
                    Content = q.Options[i],
                    Tag = i,
                    GroupName = "QuizOptions",
                    Margin = new Thickness(5)
                };
                spAnswerOptions.Children.Add(rb);
            }
        }

        private void btnSubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            if (currentQuestionIndex < 0 || currentQuestionIndex >= quizQuestions.Count)
            {
                MessageBox.Show("Please start the quiz first.");
                return;
            }

            int? selectedIndex = null;

            foreach (RadioButton rb in spAnswerOptions.Children)
            {
                if (rb.IsChecked == true)
                {
                    selectedIndex = (int)rb.Tag;
                    break;
                }
            }

            if (selectedIndex == null)
            {
                MessageBox.Show("Please select an answer.");
                return;
            }

            var q = quizQuestions[currentQuestionIndex];

            if (selectedIndex == q.CorrectOptionIndex)
            {
                score++;
                txtQuizFeedback.Text = "Correct! " + q.Explanation;
            }
            else
            {
                txtQuizFeedback.Text = "Wrong. " + q.Explanation;
            }

            currentQuestionIndex++;
            ShowQuestion(currentQuestionIndex);
        }
    }

    // Define supporting classes outside MainWindow
    public class CyberTask
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? ReminderDate { get; set; }
        public bool IsCompleted { get; set; }
    }

    public class QuizQuestion
    {
        public string Question { get; set; }
        public List<string> Options { get; set; } = new List<string>();
        public int CorrectOptionIndex { get; set; }
        public string Explanation { get; set; }
    }
}
